console.log("Bienvenido a la aplicación de consola");
alert("Aplicación de operaciones matemáticas básicas");

// Ingreso de datos
let nombreUsuario = prompt("Ingrese su nombre:");
console.log("Usuario:", nombreUsuario);

// Variables numéricas
let numero1 = Number(prompt("Ingrese el primer número:"));
let numero2 = Number(prompt("Ingrese el segundo número:"));

// Validación
if (isNaN(numero1) || isNaN(numero2)) {
  alert("Debe ingresar solo números");
} else {
  console.log("Suma:", numero1 + numero2);
  console.log("Resta:", numero1 - numero2);
  console.log("Multiplicación:", numero1 * numero2);

  if (numero2 !== 0) {
    console.log("División:", numero1 / numero2);
  } else {
    console.log("No se puede dividir por cero");
  }
}

function sumar(a, b) {
  return a + b;
}

function restar(a, b) {
  return a - b;
}

function multiplicar(a, b) {
  return a * b;
}

function dividir(a, b) {
  if (b === 0) {
    return "Error: División por cero";
  }
  return a / b;
}

console.log("Funciones:");
console.log("Suma:", sumar(10, 5));
console.log("Resta:", restar(10, 5));
console.log("Multiplicación:", multiplicar(10, 5));
console.log("División:", dividir(10, 5));
