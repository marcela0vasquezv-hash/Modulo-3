# Proyecto Módulo 3 
## Descripción
Este proyecto corresponde a una aplicación de consola desarrollada en JavaScript, cuyo objetivo es aplicar los fundamentos básicos del lenguaje, tales como variables, condicionales, ciclos, funciones, arreglos y objetos.

La aplicación permite realizar operaciones matemáticas básicas, manipular arreglos de datos y trabajar con objetos, utilizando buenas prácticas de programación y código modular.


## Funciones
- Ingreso de datos por parte del usuario mediante `prompt`.
- Validación de datos ingresados.
- Operaciones matemáticas: suma, resta, multiplicación y división.
- Uso de funciones reutilizables.
- Manipulación de arreglos y filtrado de datos.
- Uso de objetos y métodos.
- Ejecución completa en la consola del navegador.


## recursos usados
- JavaScript (ES6)
- Consola del navegador (Chrome / Edge)


## Cómo ejecutar el proyecto
1. Abrir el archivo `app.js`.
2. Copiar el código.
3. Abrir el navegador.
4. Presionar `F12` para abrir las herramientas de desarrollador.
5. Ir a la pestaña **Console**.
6. Pegar el código y presionar **Enter**.


## respaldos
Las capturas de pantalla se encuentran en la carpeta `/capturas`, mostrando la aplicación en funcionamiento desde la consola.

---

## autor
Proyecto desarrollado como parte del Módulo 3 – Fundamentos de Programación en JavaScript. Marcela Vásquez Vivanco
